# Sysexit

Immediately stops execution when imported by raising a SystemExit exception
